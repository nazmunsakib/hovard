<h3 style="margin-top: 0;"><?php esc_html_e( "Envato support integration", "smart-bbpress-nverify" ); ?></h3>
<table class="form-table" style="width: 700px;">
    <tbody>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Parse support URL", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Parse support URL", "smart-bbpress-nverify" ); ?></span></legend>
                <label for="handle_envato_support_urls">
                    <input<?php echo $settings['handle_envato_support_urls'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="handle_envato_support_urls" name="sbv[handle_envato_support_urls]">
					<?php esc_html_e( "Active", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "If you set your own support forum as a support method on Envato, item support pages will redirect to your website using item ID. This plugin will attempt to detect these URL's and redirect to appropriate forum.", "smart-bbpress-nverify" ); ?></em>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>

<h3><?php esc_html_e( "Contact Envato API to make sure it works", "smart-bbpress-nverify" ); ?></h3>
<table class="form-table" style="width: 700px;">
    <tbody>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Contact API before showing verification form", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Contact API before showing verification form", "smart-bbpress-nverify" ); ?></span>
                </legend>
                <label for="ping_envato_api">
                    <input<?php echo $settings['ping_envato_api'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="ping_envato_api" name="sbv[ping_envato_api]">
					<?php esc_html_e( "Active", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "When verification form is to be displayed, plugin will check if the Envato API is currently working. If it is not, plugin will display API status message instead of verification form. These pings are cached for the period of 2 minutes.", "smart-bbpress-nverify" ); ?></em>

                <br/><em>
                    <strong><?php esc_html_e( "This is still experimental feature, and it is possible that it will sometimes report false online status.", "smart-bbpress-nverify" ); ?></strong></em>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>

<h3><?php esc_html_e( "bbPress RSS Feeds", "smart-bbpress-nverify" ); ?></h3>
<table class="form-table" style="width: 700px;">
    <tbody>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Disable RSS Feeds", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Disable RSS Feeds", "smart-bbpress-nverify" ); ?></span></legend>
                <label for="integrate_bbpress_disable_rss_feeds">
                    <input<?php echo $settings['integrate_bbpress_disable_rss_feeds'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="integrate_bbpress_disable_rss_feeds" name="sbv[integrate_bbpress_disable_rss_feeds]">
					<?php esc_html_e( "Disable", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "bbPress RSS Feeds list all the topics and replies belonging to the forum feed, and all replies belonging to the topic feed. That can expose the topics and replies you want to protect, because feeds don't take into account logged in users due to the lack of authentication capabilities in the RSS readers software. If you want to fully protect your forums, you need to disabled these feeds. With this option, feeds in bbPress will be disabled, and redirected to parent URL's.", "smart-bbpress-nverify" ); ?></em>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>

<h3><?php esc_html_e( "bbPress User Profile", "smart-bbpress-nverify" ); ?></h3>
<table class="form-table" style="width: 700px;">
    <tbody>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Registered purchase codes", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Registered purchase codes", "smart-bbpress-nverify" ); ?></span></legend>
                <label for="integrate_bbpress_profile_active">
                    <input<?php echo $settings['integrate_bbpress_profile_active'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="integrate_bbpress_profile_active" name="sbv[integrate_bbpress_profile_active]">
					<?php esc_html_e( "Show List", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "User profile page in the forums will show all registered purchase codes, and only profile owner will see the list by default. You can allow administrators and moderators to see list of codes on profiles.", "smart-bbpress-nverify" ); ?></em>
            </fieldset>
        </td>
    </tr>
    <tr valign="top">
        <th scope="row">&nbsp;</th>
        <td>
            <fieldset>
                <label for="integrate_bbpress_profile_visible_to_administrators">
                    <input<?php echo $settings['integrate_bbpress_profile_visible_to_administrators'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="integrate_bbpress_profile_visible_to_administrators" name="sbv[integrate_bbpress_profile_visible_to_administrators]">
					<?php esc_html_e( "Show Lists to Administrators", "smart-bbpress-nverify" ); ?></label>
                <br/>
                <label for="integrate_bbpress_profile_visible_to_moderators">
                    <input<?php echo $settings['integrate_bbpress_profile_visible_to_moderators'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="integrate_bbpress_profile_visible_to_moderators" name="sbv[integrate_bbpress_profile_visible_to_moderators]">
					<?php esc_html_e( "Show Lists to Moderators", "smart-bbpress-nverify" ); ?></label>
            </fieldset>
        </td>
    </tr>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Add purchase codes in Bulk", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Add purchase codes in Bulk", "smart-bbpress-nverify" ); ?></span></legend>
                <label for="integrate_bbpress_profile_active">
                    <input<?php echo $settings['integrate_bbpress_profile_bulk_active'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="integrate_bbpress_profile_bulk_active" name="sbv[integrate_bbpress_profile_bulk_active]">
					<?php esc_html_e( "Enabled", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "Through user profile page in the forums user can add purchase codes. You can allow administrators and moderators to do this also for every user.", "smart-bbpress-nverify" ); ?></em>
            </fieldset>
        </td>
    </tr>
    <tr valign="top">
        <th scope="row">&nbsp;</th>
        <td>
            <fieldset>
                <label for="integrate_bbpress_profile_bulk_visible_to_administrators">
                    <input<?php echo $settings['integrate_bbpress_profile_bulk_visible_to_administrators'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="integrate_bbpress_profile_bulk_visible_to_administrators" name="sbv[integrate_bbpress_profile_bulk_visible_to_administrators]">
					<?php esc_html_e( "Show bulk insert to Administrators", "smart-bbpress-nverify" ); ?></label>
                <br/>
                <label for="integrate_bbpress_profile_bulk_visible_to_moderators">
                    <input<?php echo $settings['integrate_bbpress_profile_bulk_visible_to_moderators'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="integrate_bbpress_profile_bulk_visible_to_moderators" name="sbv[integrate_bbpress_profile_bulk_visible_to_moderators]">
					<?php esc_html_e( "Show bulk insert to Moderators", "smart-bbpress-nverify" ); ?></label>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>

<h3><?php esc_html_e( "Administration Control", "smart-bbpress-nverify" ); ?></h3>
<table class="form-table" style="width: 700px;">
    <tbody>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Item column for Forums", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Item column for Forums", "smart-bbpress-nverify" ); ?></span></legend>
                <label for="admin_show_forum_products_column">
                    <input<?php echo $settings['admin_show_forum_products_column'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="admin_show_forum_products_column" name="sbv[admin_show_forum_products_column]">
					<?php esc_html_e( "Show", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "Administration panel with list of forums will have extra column showing list of Envato items / products assigned to forum.", "smart-bbpress-nverify" ); ?></em>
            </fieldset>
        </td>
    </tr>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Bulk Editor Integration", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Bulk Editor Integration", "smart-bbpress-nverify" ); ?></span></legend>
                <label for="admin_show_posts_bulk_edit">
                    <input<?php echo $settings['admin_show_forum_bulk_edit'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="admin_show_forum_bulk_edit" name="sbv[admin_show_forum_bulk_edit]">
					<?php esc_html_e( "Show", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "This can be used to easier assign Envato items to more forums at once. If the item you try to add doesn't belong to default Envato account set for the plugin, it will not be added.", "smart-bbpress-nverify" ); ?></em>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>
