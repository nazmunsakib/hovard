<div id="post-<?php bbp_reply_id(); ?>" class="bbp-reply-header">
    <div class="bbp-meta">
        <span class="bbp-reply-post-date"><?php bbp_reply_post_date(); ?></span>
        <span class="bbp-header">
                <?php esc_html_e( 'in reply to: ', 'bbpress' ); ?>
                <a class="bbp-topic-permalink" href="<?php bbp_topic_permalink( bbp_get_reply_topic_id() ); ?>"><?php bbp_topic_title( bbp_get_reply_topic_id() ); ?></a>
            </span>

        <a href="<?php bbp_reply_url(); ?>" class="bbp-reply-permalink">#<?php bbp_reply_id(); ?></a>
    </div>
</div>
<div <?php bbp_reply_class( 0, 'sbv-search-access-restricted' ); ?>>
    <div class="bbp-reply-content">

		<?php sbv_show_notice( __( "You must have valid license to access this content.", "smart-bbpress-nverify" ), 'error' ); ?>

    </div>
</div>