<div class="sct-dim">
    <div id="sct-dim-outer">
        <div id="sct-dim-middle">
            <div id="sct-dim-inner">
				<?php esc_html_e( "Please wait for the verification process to complete.", "smart-bbpress-nverify" ); ?><br/>
                <em><?php esc_html_e( "In some cases, process can take few minutes minutes to complete.", "smart-bbpress-nverify" );
					echo '<br/>';
					_e( "If it takes longer than that, refresh the page.", "smart-bbpress-nverify" ); ?></em>

                <div id="sct-load-timer">00:00:00.00</div>
            </div>
        </div>
    </div>
</div>

<div class="sct-cleanup-left">
    <div id="scs-scroll-sidebar">
        <p>
			<?php esc_html_e( "From here, you can quickly verify purchase codes for your customers.", "smart-bbpress-nverify" ); ?>
        </p>
        <input id="verify_nonce" type="hidden" value="<?php echo wp_create_nonce( 'smart-bbpress-nverify' ); ?>"/>
        <input id="verify_submit" type="button" class="button-primary" value="<?php esc_attr_e( "Verify", "smart-bbpress-nverify" ); ?>"/>
    </div>
</div>
<div class="sct-cleanup-right">
    <h3 style="margin-top: 0;"><?php esc_html_e( "Account Information", "smart-bbpress-nverify" ); ?></h3>
    <table class="form-table" style="width: 700px;">
        <tbody>
        <tr valign="top">
            <th scope="row"><?php esc_html_e( "API Version", "smart-bbpress-nverify" ); ?></th>
            <td>
                <fieldset>
                    <em>
						<?php esc_html_e( "This panel can use only API version set in the main plugin settings. If you set to new API, you need to enter personal token into API Key/Token field.", "smart-bbpress-nverify" ); ?>
                    </em>
                </fieldset>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php esc_html_e( "Envato Username", "smart-bbpress-nverify" ); ?></th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text">
                        <span><?php esc_html_e( "Envato Username", "smart-bbpress-nverify" ); ?></span></legend>
                    <input type="text" class="widefat" id="verify_user_name" value="<?php echo $settings['global_user_name']; ?>"/>
                </fieldset>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php esc_html_e( "API Token", "smart-bbpress-nverify" ); ?></th>
            <td>
				<?php $_api_key = $settings['global_api_token']; ?>
                <fieldset>
                    <legend class="screen-reader-text"><span><?php esc_html_e( "API Token", "smart-bbpress-nverify" ); ?></span>
                    </legend>
                    <input type="password" class="widefat" id="verify_api_key" value="<?php echo $_api_key; ?>"/>
                </fieldset>
            </td>
        </tr>
        </tbody>
    </table>
    <h3><?php esc_html_e( "Purchase Code", "smart-bbpress-nverify" ); ?></h3>
    <table class="form-table" style="width: 700px;">
        <tbody>
        <tr valign="top">
            <th scope="row"><?php esc_html_e( "Purchase Code", "smart-bbpress-nverify" ); ?></th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text">
                        <span><?php esc_html_e( "Purchase Code", "smart-bbpress-nverify" ); ?></span></legend>
                    <input type="text" class="widefat" id="verify_purchase_code" value="" style="font-family: monospace;"/>
                </fieldset>
            </td>
        </tr>
        <tr valign="top">
            <th scope="row"><?php esc_html_e( "Assign to User with ID", "smart-bbpress-nverify" ); ?></th>
            <td>
                <fieldset>
                    <legend class="screen-reader-text">
                        <span><?php esc_html_e( "Assign to User with ID", "smart-bbpress-nverify" ); ?></span></legend>
                    <input type="number" class="widefat" id="verify_assign_id" value="0" style="width: 128px;"/>

                    <br/><em>
						<?php esc_html_e( "If purchase code is valid, not currently assigned to any user, and if User ID exists, purchase code will be assigned to this user.", "smart-bbpress-nverify" ); ?>
                    </em>
                </fieldset>
            </td>
        </tr>
        </tbody>
    </table>
    <div id="svb-quick-verify-result"></div>
</div>
