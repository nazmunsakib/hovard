<h3 style="margin-top: 0;"><?php esc_html_e( "Impact Radius Affiliate Account", "smart-bbpress-nverify" ); ?></h3>
<table class="form-table" style="width: 700px;">
    <tbody>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Your Affiliate ID", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Your Affiliate ID", "smart-bbpress-nverify" ); ?></span></legend>
                <input type="text" class="widefat" name="sbv[impact_id]" value="<?php echo $settings['impact_id']; ?>"/>

                <br/><em>
					<?php esc_html_e( "Your own Impact Radius Affiliate ID. To get this ID, you must sign up on Impact Radius website and join Envato Market affiliate program.", "smart-bbpress-nverify" ); ?>
                </em>
            </fieldset>
        </td>
    </tr>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Ad Affiliate ID", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Ad Affiliate ID", "smart-bbpress-nverify" ); ?></span></legend>
                <input type="text" class="widefat" name="sbv[impact_ad]" value="<?php echo $settings['impact_ad']; ?>"/>

                <br/><em>
					<?php esc_html_e( "ID of the ad you want to use for tracking purposes. Different Ad ID's can be found on the ImpactRadius profile for Envato Market Ads (this ID is listed under the name of individual Ads).", "smart-bbpress-nverify" ); ?>
                </em>
            </fieldset>
        </td>
    </tr>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Envato Market ID", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Envato Market ID", "smart-bbpress-nverify" ); ?></span></legend>
                <input type="text" class="widefat" name="sbv[impact_affiliate]" value="<?php echo $settings['impact_affiliate']; ?>"/>

                <br/><em>
					<?php esc_html_e( "ID of the Envato Market on Impact Radius.", "smart-bbpress-nverify" ); ?>
                </em>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>
