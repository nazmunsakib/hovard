=== Smart bbPress nVerify - Plugin for WordPress and Envato Market ===
Version: 3.8.1
Requires at least: 5.0
Requires PHP: 7.0
Tested up to: 5.8

Integrate with bbPress forums to implement verification of the Envato purchase codes. Assign one or more Envato items to forums for purchase only access.

== Installation ==
= General Requirements =
* PHP: 7.9 or newer
* mySQL: 5.1 or newer
* WordPress: 5.0 or newer

= PHP Notice =
* The plugin doesn't work with PHP 5.6 or older versions.

= WordPress Notice =
* The plugin doesn't work with WordPress 4.9 or older versions.

= Basic Installation =
* Plugin folder in the WordPress plugins folder must be `smart-bbpress-nverify`.
* Upload folder `smart-bbpress-nverify` to the `/wp-content/plugins/` directory
* Activate the plugin through the 'Plugins' menu in WordPress
* Plugin panel is in 'Settings' => 'Smart bbPress nVerify' menu in WordPress

== Frequently Asked Questions ==
= Does plugin works with WordPress MultiSite installations? =
Yes. Each website in network can activate and use plugin on it's on.

= Can I translate plugin to my language? =
Yes. POT file is provided as a base for translation. Translation files should go into Languages directory.

== Changelog ==
= 3.8.1 / 2021.06.12 =
* Changed: Various core code improvements related to PHP 7
* Updated: Few more improvements to the current URL function
* Fixed: PHP 7 compatibility issue with the current URL function

= 3.8 / 2021.03.20 =
* Updated: Support for WordPress 5.7
* Updated: Minimal requirement: WordPress 5.0
* Updated: Minimal requirement: PHP 7.0
* Updated: Using WordPress code style
* Updated: Safe use: __ replaced with esc_html__ and esc_attr__
* Updated: Safe use: _e replaced with esc_html_e and esc_attr_e
* Updated: Most of the JavaScript code has been rewritten
* Changed: Using Smart Envato API Library 5.5

= 3.7 / 2020.06.13 =
* Changed: Various core code improvements and cleanup
* Changed: Various improvements to the plugin JavaScript
* Changed: Using Smart Envato API Library 5.4
* Fixed: Some minor styling issues on frontend

= 3.6 / 2019.03.25 =
* Added: Protection of the search results
* Added: Impact Radius Affiliates program support
* Added: Additional information about Envato API personal token
* Updated: Various improvements to the plugin JavaScript
* Updated: Support for any case usernames for validation purposes
* Updated: Plugin requires WordPress 4.5 or newer
* Updated: Plugin requires PHP 5.6 or newer
* Updated: HideShow Password plugin for jQuery 2.1.1
* Updated: Using Smart Envato API 5.3
* Fixed: Items validation fails due to the username case

= 3.5.1 / 2017.09.26 =
* Fixed: Broken forums editing metabox for adding items

= 3.5 / 2017.06.06 =
* Added: Option to close forum and topic RSS feeds
* Added: Option to protect only the single reply template
* Updated: Plugin requires WordPress 4.0 or newer
* Updated: Plugin requires PHP 5.3 or newer
* Updated: Improvements to the JavaScript loading
* Updated: JavaScript only minified, no longer packed
* Updated: Purchase code verification images
* Updated: Various improvements to the core code
* Removed: Unused JavaScript library
* Removed: Legacy Envato API support

= 3.3 / 2016.05.15 =
* Added: Option to disable support status check for purchases made before September 1, 2015
* Added: Option to control support for retired or disabled items
* Added: Assign purchase code to user from admin side Quick Verify panel
* Added: Function to validate and add purchase code to any user
* Added: Actions fired when purchase code is validated or revalidated
* Added: Centralized validation object used by different plugin elements
* Updated: Message displayed in plugin settings if account is not setup correctly
* Updated: Bulk import list template for items that are no longer available
* Updated: Improvements to detection of the Envato online status
* Updated: Many improvements to plugin code organization
* Updated: Small improvements in the styling for the frontend
* Fixed: Envato API online status was not cached correctly
* Fixed: Problem with multiple items per forum validation
* Fixed: Problem with user meta cache after revalidation

= 3.2 / 2016.03.31 =
* Added: Metabox for forum shows support check dropdown
* Added: Check online status of the API and show message if down
* Added: Template to show message if the Envato API is down
* Added: Customers list shows if the purchase code is expired or outdated
* Added: Tool to delete error log file
* Updated: Using Smart Envato API 5.0
* Fixed: Purchase code verification fails to check support expiration
* Fixed: Purchase code revalidation wrongly marks code as supported
* Fixed: Small register link issue with the login required template
* Fixed: Getting current page URL when used with SSL was not valid

= 3.1.1 / 2015.09.09 =
* Fixed: Missing function in login required template

= 3.1 / 2015.09.09 =
* Added: Protection method: Protect only topic reply form
* Added: More specific messages for different protection forms
* Added: Function to check access to individual forums
* Updated: Images for step by step Purchase Code instructions
* Updated: Improved user profile display of purchase codes
* Updated: Masked Input plugin for jQuery 1.4.1
* Updated: Using Smart Envato API 4.1.1
* Deleted: Removed jQueryUI in favor of using built-in WordPress dialog
* Fixed: Loading of bbPress profile templates without bbPress template loader
* Fixed: Critical error on the user profile page with list of purchase codes

= 3.0 / 2015.08.31 =
* Added: Support for New Envato API using Personal Token
* Added: Support for Envato Support Bundle / Package verification
* Added: Option to revalidate all purchase codes for selected user
* Updated: Rewritten code for handling API calls through new object
* Updated: Improved structure and calls made to main plugin object
* Updated: Many improvements to the process of verification
* Updated: Many improvements to the process of revalidation
* Updated: bbPress profile template shows if item exists and if support expired
* Updated: Few minor styling changes for bbPress profile
* Updated: Using Smart Envato API 4.1
* Fixed: Few problems with revalidation of the purchase codes
* Fixed: Several minor issues with Legacy API code
* Fixed: XSS vulnerability with admin side tabs loader

= 2.5.1 / 2015.04.24 =
* Fixed: One instance of add_query_arg() was not properly escaped

= 2.5 / 2015.03.29 =
* Added: API error log file and error display tools
* Added: Unified Settings panel with inner tabs
* Added: Search through Customers list by purchase code
* Added: Option to show hidden Envato API key on admin panels
* Added: Clear all cached data on plugin update
* Updated: Using Smart Envato API 3.3
* Updated: Detection of the connection related errors
* Updated: Many changes to handling calls to Envato API
* Updated: Many small interface improvements
* Updated: WordPress minimum requirement is now 3.6
* Updated: Translation file missing strings
* Updated: Masked Input plugin for jQuery 1.4
* Fixed: Minor issue with bulk edit of forums
* Fixed: Display of item that is removed from Envato

= 2.3 / 2014.09.17 =
* Added: Tool to clear all Envato API cached data

= 2.2 / 2014.07.30 =
* Fix: Unlinking code from user leaves extra record in database
* Fix: Problem with escaping SQL elements in the customers grid
* Fix: Several small code formatting and display issues

= 2.1 / 2014.07.01 =
* Updated: All API calls now include user agent
* Updated: Using Smart Envato API 2.8

= 2.0 / 2014.04.10 =
* Added: Protection based on any available item purchase code
* Added: bbPress user profile with list users purchase codes
* Added: bbPress user profile with form for bulk adding of codes
* Added: Option to set default marketplace for your account
* Added: Customers list option to remove any purchase code
* Added: Customers list option to open user profile page
* Added: Customers list with more columns with useful information
* Updated: Settings tab split into two for better organization
* Updated: Refactoring of CSS and JavaScript files
* Updated: jQueryUI updated to latest 1.10.4 version
* Deleted: Removed current balance display from Account page
* Fix: Unable to add items when creating new forum, before publishing
* Fix: Several terminology and string translation issues

= 1.5 / 2013.12.29 =
* Added: Handling of the Envato Support redirection URL's
* Added: Integration with the Forums bulk editor
* Added: Purchase code steps hidden by default
* Added: Handle protection of forms with Forum selection
* Updated: Few changes to display of customers grid
* Updated: Some minor styling changes
* Fix: Not showing all items required to visitors
* Fix: Possible adding of duplicated items

= 1.0 / 2013.12.11 =
* First release
