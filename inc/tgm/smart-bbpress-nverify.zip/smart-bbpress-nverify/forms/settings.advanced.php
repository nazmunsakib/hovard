<h3 style="margin-top: 0;"><?php esc_html_e( "Multiple Authors Accounts", "smart-bbpress-nverify" ); ?></h3>
<table class="form-table" style="width: 700px;">
    <tbody>
    <tr valign="top">
        <th scope="row"><?php esc_html_e( "Allow Multiple Authors", "smart-bbpress-nverify" ); ?></th>
        <td>
            <fieldset>
                <legend class="screen-reader-text">
                    <span><?php esc_html_e( "Multiple Authors", "smart-bbpress-nverify" ); ?></span></legend>
                <label for="allow_multiple_users">
                    <input<?php echo $settings['allow_multiple_users'] ? ' checked="checked"' : ''; ?> type="checkbox" value="1" id="allow_multiple_users" name="sbv[allow_multiple_users]">
					<?php esc_html_e( "Active", "smart-bbpress-nverify" ); ?></label>

                <br/><em>
					<?php esc_html_e( "Main Author Account must be set always. With this option, adding items to forums allows you to specify different authors for each item.", "smart-bbpress-nverify" ); ?></em>

                <br/><em>
					<?php esc_html_e( "Each author account specified will use API specified in the options and you need to provide API key for Legacy API or API Token for new API.", "smart-bbpress-nverify" ); ?></em>
            </fieldset>
        </td>
    </tr>
    </tbody>
</table>