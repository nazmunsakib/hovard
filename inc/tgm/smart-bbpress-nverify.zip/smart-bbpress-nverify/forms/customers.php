<?php require_once( SBV_PATH . 'core/customers.php' ); ?>
<form method="get" action="">
    <div class="sct-cleanup-full">
        <input type="hidden" name="page" value="smart-bbpress-nverify"/>
        <input type="hidden" name="tab" value="customers"/>

		<?php

		$_grid = new sbv_customers_grid();
		$_grid->prepare_items();
		$_grid->search_box( esc_html__( "Search by Purchase Code", "smart-bbpress-nverify" ), 'purchasecode' );

		?>

        <div class="clear"></div>

		<?php $_grid->display(); ?>
    </div>
</form>

<div style="display: none">
    <div id="sbv-dialog-code-details" title="<?php esc_attr_e( "Purchase Data", "smart-bbpress-nverify" ); ?>">
        <div id="sbv-code-details-content"></div>
    </div>

    <div id="sbv-dialog-code-removal" title="<?php esc_attr_e( "Remove Purchase Code", "smart-bbpress-nverify" ); ?>">
		<?php esc_html_e( "This operation will unlink the purchase code from user, and will remove code from database, so that some other user can register and validate this purchase code.", "smart-bbpress-nverify" ); ?>
        <br/><br/>
		<?php esc_html_e( "Code to unlink", "smart-bbpress-nverify" ); ?>:<br/><span id="sbv-remove-code-placeholder"></span>
    </div>
</div>

<script type="text/javascript">
    jQuery(document).ready(function() {
        sbv_admin.panels.customers();
    });
</script>