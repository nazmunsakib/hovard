<div class="sct-cleanup-left">
    <p>
		<?php esc_html_e( "For various reasons, Envato API calls can fail if API is down, connection problems, configuration problems. All the errors will get logged into the file you can see on this panel.", "smart-bbpress-nverify" ); ?>
    </p>
</div>
<div class="sct-cleanup-right">
    <h3 style="margin-top: 0;"><?php esc_html_e( "Error Log Contents", "smart-bbpress-nverify" ); ?></h3>
	<?php

	$log = sbv_api()->get_log_file_contents();

	if ( is_wp_error( $log ) ) {
		echo '<p><strong>' . $log->get_error_message() . '</strong></p>';
		echo '<p>' . esc_html__( "Log is saved in WordPress Uploads folder, and this folder needs to be writable for log file to be created.", "smart-bbpress-nverify" ) . '</p>';
	} else {
		echo '<div id="sct-log-content"><pre>' . $log . '</pre></div>';
	}

	?>
</div>