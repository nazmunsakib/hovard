<div id="sbv-protection-block">
    <fieldset class="bbp-form">
        <legend><?php esc_html_e( "Problem with Envato API", "smart-bbpress-nverify" ); ?></legend>

		<?php sbv_show_notice( esc_html__( "Envato API can't be reached at this time, please wait few minutes before trying again.", "smart-bbpress-nverify" ), 'info' ); ?>
    </fieldset>
</div>
