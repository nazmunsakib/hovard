<?php

global $sbv_default_notice;

if ( is_user_logged_in() ) {
	$sbv_default_notice = __( "You must have valid license to reply to this topic.", "smart-bbpress-nverify" );

	if ( sbv_bbpress()->support_check == 'ok' ) {
		if ( sbv_bbpress()->ping() ) {
			bbp_get_template_part( 'nverify', 'protected-access' );
		} else {
			bbp_get_template_part( 'nverify', 'api-error' );
		}
	} else {
		bbp_get_template_part( 'nverify', 'support-expired' );
	}
} else {
	$sbv_default_notice = __( "You must be logged in and have valid license to reply to this topic.", "smart-bbpress-nverify" );

	bbp_get_template_part( 'nverify', 'login-required' );
}
