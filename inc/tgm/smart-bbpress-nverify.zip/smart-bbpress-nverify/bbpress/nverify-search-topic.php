<div id="post-<?php bbp_topic_id(); ?>" class="bbp-topic-header">
    <div class="bbp-meta">
        <span class="bbp-topic-post-date"><?php bbp_topic_post_date(); ?></span>
        <span class="bbp-header">
                <?php esc_html_e( 'in topic: ', 'bbpress' ); ?>
                <a class="bbp-reply-permalink" href="<?php bbp_topic_permalink(); ?>"><?php bbp_topic_title(); ?></a>
            </span>

        <a href="<?php bbp_topic_permalink(); ?>" class="bbp-topic-permalink">#<?php bbp_topic_id(); ?></a>
    </div>
</div>
<div <?php bbp_topic_class( 0, 'sbv-search-access-restricted' ); ?>>
    <div class="bbp-topic-content">

		<?php sbv_show_notice( __( "You must have valid license to access this content.", "smart-bbpress-nverify" ), 'error' ); ?>

    </div>
</div>