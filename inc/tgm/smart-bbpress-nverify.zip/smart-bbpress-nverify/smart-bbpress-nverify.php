<?php

/*
Plugin Name: Smart bbPress nVerify - Plugin for WordPress and Envato Market
Plugin URI: https://www.smartplugins.info/plugin/wordpress/smart-bbpress-nverify/
Description: Integrate with bbPress forums to implement verification of the Envato purchase codes. Assign one or more Envato items to forums for purchase only access.
Version: 3.8.1
Author: Milan Petrovic
Author URI: https://www.dev4press.com/

== Copyright ==
Copyright 2008 - 2021 Milan Petrovic (email: support@smartplugins.info)
*/

class sbv_loader {
	public $settings = array();

	function __construct() {
		global $wp_version;

		define( 'SBV_WPV', $wp_version );
		define( 'SBV_WP_VERSION', intval( substr( str_replace( '.', '', $wp_version ), 0, 2 ) ) );

		$_dirname = trailingslashit( dirname( __FILE__ ) );
		$_urlname = plugin_dir_url( __FILE__ );

		define( 'SBV_PATH', $_dirname );
		define( 'SBV_URL', $_urlname );

		require_once( SBV_PATH . 'core/defaults.php' );

		if ( ! defined( 'SBV_EOL' ) ) {
			define( 'SBV_EOL', "\r\n" );
		}

		require_once( SBV_PATH . 'core/functions/d4plib.php' );
		require_once( SBV_PATH . 'core/functions/internal.php' );
		require_once( SBV_PATH . 'core/functions/public.php' );
		require_once( SBV_PATH . 'core/functions/render.php' );

		require_once( SBV_PATH . 'core/objects/validator.php' );
		require_once( SBV_PATH . 'core/objects/bbpress.php' );

		if ( is_admin() ) {
			require_once( SBV_PATH . 'core/admin.php' );
		}

		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			require_once( SBV_PATH . 'core/ajax.php' );
		}

		add_action( 'plugins_loaded', array( $this, 'init_plugin_settings' ), 9 );
		add_action( 'plugins_loaded', array( $this, 'init_translation' ) );
	}

	public function init_translation() {
		$this->l = get_locale();

		if ( ! empty( $this->l ) ) {
			load_plugin_textdomain( 'smart-bbpress-nverify', false, 'smart-bbpress-nverify/languages' );
		}
	}

	public function init_plugin_settings() {
		$_d = new sbv_defaults();

		$this->settings = get_option( 'smart-bbpress-nverify' );

		$clear_cache = false;

		if ( ! is_array( $this->settings ) ) {
			$this->settings = $_d->settings;
			update_option( 'smart-bbpress-nverify', $this->settings );

			$clear_cache = true;
		} else if ( $this->settings['__build__'] != $_d->settings['__build__'] ) {
			$this->settings = $_d->upgrade( $this->settings );
			update_option( 'smart-bbpress-nverify', $this->settings );

			$clear_cache = true;
		}

		define( 'SMART_BBPRESS_NVERIFY', $this->settings['__version__'] );

		require_once( SBV_PATH . 'core/objects/api.php' );

		if ( $clear_cache ) {
			sbv_api()->clear_cache();
		}

		do_action( 'sbv_init_plugin_settings' );
	}

	public function get( $name ) {
		return $this->settings[ $name ];
	}

	public function set( $name, $value ) {
		$this->settings[ $name ] = $value;
	}

	public function save() {
		update_option( 'smart-bbpress-nverify', $this->settings );
	}
}

global $sbv_core_loader;
$sbv_core_loader = new sbv_loader();

/** @return sbv_loader */
function smart_sbv_core() {
	global $sbv_core_loader;

	return $sbv_core_loader;
}
