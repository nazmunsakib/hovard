<div class="clear"></div>
<div id="sbv-bulk-edit-block">
    <div class="sbv-bulk-left">
        <span><?php esc_html_e( "Envato Items Operation", "smart-bbpress-nverify" ); ?>:</span>

        <select name="sbv_envato_items_action">
            <option value="noc" selected="selected">&mdash; <?php esc_html_e( "No Change", "smart-bbpress-nverify" ); ?> &mdash;</option>
            <option value="add"><?php esc_html_e( "Append listed ID's to all forums", "smart-bbpress-nverify" ); ?></option>
            <option value="rep"><?php esc_html_e( "Replace with listed ID's for all forums", "smart-bbpress-nverify" ); ?></option>
            <option value="del"><?php esc_html_e( "Remove all ID's from all forums", "smart-bbpress-nverify" ); ?></option>
            <option value="rem"><?php esc_html_e( "Remove listed ID's from all forums", "smart-bbpress-nverify" ); ?></option>
        </select>
    </div>
    <div class="sbv-bulk-right">
        <span><?php esc_html_e( "List of Items ID's (comma separated)", "smart-bbpress-nverify" ); ?>:</span>

        <input type="text" value="" name="sbv_envato_items_list"/>
    </div>
</div>