<form method="post" action="">
	<?php settings_fields( 'smart-bbpress-nverify-settings' ); ?>

    <div class="sct-cleanup-left">
        <div id="scs-scroll-sidebar">
            <p>
				<?php esc_html_e( "Settings for control over forums access restriction, revalidation, verification and other plugin features.", "smart-bbpress-nverify" ); ?>
            </p>
            <input type="submit" class="button-primary" value="<?php esc_attr_e( "Save Settings", "smart-bbpress-nverify" ); ?>"/>
        </div>
    </div>
    <div class="sct-cleanup-right sct-with-tabber">
        <ul class="sct-tabs-list">
            <li class="sct-current-tab"><a href="#nverify_account"><?php esc_html_e( "Envato", "smart-bbpress-nverify" ); ?></a>
            </li>
            <li><a href="#nverify_impact"><?php esc_html_e( "Affiliates", "smart-bbpress-nverify" ); ?></a></li>
            <li><a href="#nverify_support"><?php esc_html_e( "Support", "smart-bbpress-nverify" ); ?></a></li>
            <li><a href="#nverify_verification"><?php esc_html_e( "Verification", "smart-bbpress-nverify" ); ?></a></li>
            <li><a href="#nverify_validation"><?php esc_html_e( "Validation", "smart-bbpress-nverify" ); ?></a></li>
            <li><a href="#nverify_integration"><?php esc_html_e( "Integration", "smart-bbpress-nverify" ); ?></a></li>
            <li><a href="#nverify_advanced"><?php esc_html_e( "Advanced", "smart-bbpress-nverify" ); ?></a></li>
        </ul>
        <div class="sct-tabs-content">
            <div id="nverify_account" class="sct-tab sct-current-content">
				<?php include( SBV_PATH . 'forms/settings.account.php' ); ?>
            </div>
            <div id="nverify_impact" class="sct-tab">
				<?php include( SBV_PATH . 'forms/settings.impact.php' ); ?>
            </div>
            <div id="nverify_support" class="sct-tab">
				<?php include( SBV_PATH . 'forms/settings.support.php' ); ?>
            </div>
            <div id="nverify_verification" class="sct-tab">
				<?php include( SBV_PATH . 'forms/settings.verification.php' ); ?>
            </div>
            <div id="nverify_validation" class="sct-tab">
				<?php include( SBV_PATH . 'forms/settings.validation.php' ); ?>
            </div>
            <div id="nverify_integration" class="sct-tab">
				<?php include( SBV_PATH . 'forms/settings.integration.php' ); ?>
            </div>
            <div id="nverify_advanced" class="sct-tab">
				<?php include( SBV_PATH . 'forms/settings.advanced.php' ); ?>
            </div>
        </div>
    </div>
</form>

<script type="text/javascript">
    jQuery(document).ready(function() {
        window.wp.smartplugins.admin.tabs();
    });
</script>